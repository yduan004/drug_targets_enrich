library(testthat)
library(clusterProfiler2)

test_check("clusterProfiler2")
