DOSE2: Disease Ontology Semantic and Enrichment analysis
=======================================================

[![](https://img.shields.io/badge/release%20version-3.0.10-green.svg?style=flat)](https://bioconductor.org/packages/DOSE2) [![](https://img.shields.io/badge/devel%20version-3.1.3-green.svg?style=flat)](https://github.com/guangchuangyu/DOSE2) [![Bioc](http://www.bioconductor.org/shields/years-in-bioc/DOSE2.svg)](https://www.bioconductor.org/packages/devel/bioc/html/DOSE2.html#since) [![](https://img.shields.io/badge/download-37631/total-blue.svg?style=flat)](https://bioconductor.org/packages/stats/bioc/DOSE2) [![](https://img.shields.io/badge/download-1575/month-blue.svg?style=flat)](https://bioconductor.org/packages/stats/bioc/DOSE2)

[![Project Status: Active - The project has reached a stable, usable state and is being actively developed.](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active) [![codecov](https://codecov.io/gh/GuangchuangYu/DOSE2/branch/master/graph/badge.svg)](https://codecov.io/gh/GuangchuangYu/DOSE2/) [![Last-changedate](https://img.shields.io/badge/last%20change-2017--03--27-green.svg)](https://github.com/GuangchuangYu/DOSE2/commits/master) [![commit](http://www.bioconductor.org/shields/commits/bioc/DOSE2.svg)](https://www.bioconductor.org/packages/devel/bioc/html/DOSE2.html#svn_source) [![GitHub forks](https://img.shields.io/github/forks/GuangchuangYu/DOSE2.svg)](https://github.com/GuangchuangYu/DOSE2/network) [![GitHub stars](https://img.shields.io/github/stars/GuangchuangYu/DOSE2.svg)](https://github.com/GuangchuangYu/DOSE2/stargazers)

[![platform](http://www.bioconductor.org/shields/availability/devel/DOSE2.svg)](https://www.bioconductor.org/packages/devel/bioc/html/DOSE2.html#archives) [![Build Status](http://www.bioconductor.org/shields/build/devel/bioc/DOSE2.svg)](https://bioconductor.org/checkResults/devel/bioc-LATEST/DOSE2/) [![Linux/Mac Travis Build Status](https://img.shields.io/travis/GuangchuangYu/DOSE2/master.svg?label=Mac%20OSX%20%26%20Linux)](https://travis-ci.org/GuangchuangYu/DOSE2) [![AppVeyor Build Status](https://img.shields.io/appveyor/ci/Guangchuangyu/DOSE2/master.svg?label=Windows)](https://ci.appveyor.com/project/GuangchuangYu/DOSE2) [![install with bioconda](https://img.shields.io/badge/install%20with-bioconda-green.svg?style=flat)](http://bioconda.github.io/recipes/bioconductor-DOSE2/README.html)

This package implements five methods proposed by *Resnik*, *Schlicker*, *Jiang*, *Lin* and *Wang* respectively for measuring semantic similarities among DO terms and gene products. Enrichment analyses including hypergeometric model and gene set enrichment analysis are also implemented for discovering disease associations of high-throughput biological data.

[![Twitter](https://img.shields.io/twitter/url/https/github.com/GuangchuangYu/DOSE2.svg?style=social)](https://twitter.com/intent/tweet?hashtags=DOSE2&url=http://bioinformatics.oxfordjournals.org/content/31/4/608)

------------------------------------------------------------------------

Please cite the following article when using `DOSE2`:

***G Yu***, LG Wang, GR Yan, QY He. DOSE2: an R/Bioconductor package for Disease Ontology Semantic and Enrichment analysis. ***Bioinformatics*** 2015, 31(4):608-609.

[![](https://img.shields.io/badge/doi-10.1093/bioinformatics/btu684-green.svg?style=flat)](http://dx.doi.org/10.1093/bioinformatics/btu684) [![citation](https://img.shields.io/badge/cited%20by-30-green.svg?style=flat)](https://scholar.google.com.hk/scholar?oi=bibs&hl=en&cites=16627502277303919270) [![](https://img.shields.io/badge/Altmetric-35-green.svg?style=flat)](https://www.altmetric.com/details/2788597)

------------------------------------------------------------------------

For details, please visit our project website, <https://guangchuangyu.github.io/DOSE2>.

-   [Documentation](https://guangchuangyu.github.io/DOSE2/documentation/)
-   [Featured Articles](https://guangchuangyu.github.io/DOSE2/featuredArticles/)
-   [Feedback](https://guangchuangyu.github.io/DOSE2/#feedback)

### Citation

[![citation](https://img.shields.io/badge/cited%20by-30-green.svg?style=flat)](https://scholar.google.com.hk/scholar?oi=bibs&hl=en&cites=16627502277303919270)

       +-+------------+-----------+------------+-----------+---+
       |                          *                            |
    15 +                                                       +
       |                                                       |
       |                                                       |
       |                                                       |
       |                                                       |
    10 +                                                       +
       | *                                                     |
       |                                                       |
       |                                                       |
       |                                                       |
     5 +                                                   *   +
       +-+------------+-----------+------------+-----------+---+
       2015        2015.5       2016        2016.5       2017   

### Download stats

[![download](http://www.bioconductor.org/shields/downloads/DOSE2.svg)](https://bioconductor.org/packages/stats/bioc/DOSE2) [![](https://img.shields.io/badge/download-37631/total-blue.svg?style=flat)](https://bioconductor.org/packages/stats/bioc/DOSE2) [![](https://img.shields.io/badge/download-1575/month-blue.svg?style=flat)](https://bioconductor.org/packages/stats/bioc/DOSE2)

         +-----------+--------------+--------------+-------------+--------------+--------------+-------+
    3000 +                                                                                    *        +
         |                                                                                             |
         |                                                                                        *    |
    2500 +                                                                                   *         +
         |                                                                            *  *      *      |
         |                                                                                *            |
         |                                                                              *  *   *       |
    2000 +                                                                           *                 +
         |                                                                                             |
         |                                                                                             |
    1500 +                                                                                             +
         |                                                                        * *                  |
         |                                                                *  ****                      |
         |                                                                 *       *                   |
    1000 +                                                            * **                             +
         |                                                    *    ***                                 |
         |                                             * ****  **                                      |
     500 +                               ***   ****   *          *                                     +
         |                *      *     *    * *     *                                                  |
         |              *  *** *  * ***              *                                                 |
         |         * ***        *                                                                      |
       0 +   ** ***                                                                                    +
         +-----------+--------------+--------------+-------------+--------------+--------------+-------+
                   2012           2013           2014          2015           2016           2017
