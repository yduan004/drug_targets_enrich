library(DOSE2)

context("gene2DO")

test_that("gene2DO", {
    
    expect_equal(DOSE2:::gene2DO('3'),
                 DOSE2:::gene2DO(3))

})


