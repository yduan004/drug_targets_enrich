library(testthat)
library(DOSE2)

test_check("DOSE2")

